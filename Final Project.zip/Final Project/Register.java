import java.util.ArrayList;
public class Register
{
    /*
     *list of drinks to choose from 
     plus price
     add name and thenhoose as many drink and delte and add 
     */
    private ArrayList <String> listOfDrinks;
    private ArrayList <Order> orders;
    private String registerWorker;
    public Register(String worker){
        registerWorker = worker;
        
    }
}
