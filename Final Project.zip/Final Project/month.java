public class month
{
    /* barasita list for each day
     income total
     income per day
     most popular 
     */
     private String name;
     private double totalIncome = 0;
     private double incomePerDay = 0;
     private String mostpop;
     private Day[] days; 
    public month(String name, int numDay){
         this.name = name;
         days = new Day[numDay];
    }
     public boolean addDay(Day d1){
        for(int i = 0; i < days.length; i++){
            if(days[i] == null){
                days[i] = d1;
                return true;
            }
        }
        return false;
    }
    
}