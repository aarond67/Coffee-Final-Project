public class Day
{
    /*barasta term for the day
     income for the day
     date
      orders with list of drinks and prices
      orders made and then recursion to find the specific persona then order sort
     */
}
