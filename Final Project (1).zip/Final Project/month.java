public class month
{
    /* barasita list for each day
     income total
     income per day
     most popular 
     */
}
