public class Register
{
    /*
     *list of drinks to choose from 
     plus price
     add name and thenhoose as many drink and delte and add 
     */
    public Register(String barastia){
        
    }
}
